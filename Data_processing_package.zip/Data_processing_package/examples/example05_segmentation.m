% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Registration and segmentation of the functional scans
load('scanAverage.mat');   % loads the average scan of one session. This file is the result of the example 'example02_filter_average.m'
load('Transformation.mat');   % loads the transformation matrix file result of 'example01_registering.m'
load('allen_brain_atlas.mat');    % loads the Allen Mouse CCF


% segment all regions
% the Lut prepares the work for a fast segmentation of all scans with the
% same trasfrormation.
Lut=lutSegmentation(Transf,atlas,scanfus);  
scanfusSegmented=segmentation(Lut,scanfus); 


% Selection of a subset of brain regions listed in 'list_selected_regions.txt'.
regionSelection=selectBrainRegions(atlas,'listSelectedRegions.txt',scanfusSegmented);

%% Visualization of the z-score time-courses for individual brain regions (registered)
close all
figure(1);

% in this example we averaged both hemispheres
% and normalize as Z score with 30 points in the baseline.
regionTotal=regionSelection.Left+regionSelection.Right;
nbaseline=30;  % 30 points of baseline
for ir=1:size(regionTotal,1)
    regionTotal(ir,:)=(regionTotal(ir,:)-mean(regionTotal(ir,1:nbaseline),2))/(std(regionTotal(ir,1:nbaseline),[],2)+1e-10);
end

imagesc(regionTotal); 
title (' z-score ');
xlabel('Time (images)');
ylabel('Regions')
caxis([-6 6]);
colormap (jet)