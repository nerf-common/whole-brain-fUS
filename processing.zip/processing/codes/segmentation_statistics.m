% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020
%
% Statistic analysis of region-time traces for multiple sessions
%
% [rtMean,tscore,pvalue]=segmentation_statistics(rtSessions,T1,T2)
%   rtSessions 3D matrix (regions,time,sessions) obtained using
%       the function example05_segmentation for each session.
%   T2, T2, initial and final time of the stimulus.
%   rtMean 2D matrix (region,time) average region-time trace over the sessions
%   tscore 1D vector (regions) t-score of the activity in each region.
%   pvalue 1D vector (regions) p-value for 1 tail t-test
%
% Example! example07_multisession_segmentation.m
%%
function [rtMean,tscore,pvalue]=segmentation_statistics(rtSessions,T1,T2)

rtMean=mean(rtSessions,3);

stim=zeros(70,1);
stim(T1:T2,:)=1;                         % activity is a square window
hrf = hemodynamic_response(0.1,[1.5 10 0.5 1 20 0 16]); % hemodynamic response 
stim=filter(hrf,1,stim);                 % filter the activity by the hrf
stim=stim./sqrt(sum(stim.^2));

[nr,~,nrep]=size(rtSessions);
c=zeros(nr,nrep);
for irep=1:nrep
    for ir=1:nr
        s=squeeze(rtSessions(ir,:,irep))';
        s=s-mean(s);
        s=s/sqrt(sum(s.^2));
        c(ir,irep)=sum(s.*stim);
    end
end

cm=mean(c,2);                         % mean value
tscore=cm./std(c,[],2)*sqrt(nrep);    % t score 
pvalue= 1- tcdf(tscore,nrep); 
end