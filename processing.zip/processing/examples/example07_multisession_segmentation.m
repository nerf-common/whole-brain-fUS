% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Region-time statistics for multiple sessions
% The file 'segmentation16sessions.mat' has a structure segmentation.Right(region,time,session) and segmentation.Left(region,time,session)
% obtained by running the example 'example05_segmentation.m'.
load('segmentation8sessions','segmentation');

%% Compute the statistical analysis
data=segmentation.Right+segmentation.Left;   % in this example both hemispheres are averaged
[rtMean,tscore,pvalue]=segmentation_statistics(data,34,44); % Performs the statistics

%% Visualization of the region-time traces (registered)
close all
figure(1);
subplot(1,2,1)
imagesc(rtMean); 
xlabel('Time (samples)');
ylabel('Regions')
title('Region-time trace')
caxis([-6 6]);
colormap (jet)
subplot(1,2,2);

% find regions significantly activated 
signReg=find(pvalue<0.001);
plot(flip(tscore),[-length(tscore):-1],0,-signReg,'*r'); axis([-5 20 -length(tscore),-1])
title('t-score - pvalue<0.001');

