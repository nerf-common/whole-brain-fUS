% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Multi-session maps
% The file 'maps16sessions.mat' is a 4D matrix C(x,y,z,session) with registered correlations from 16 sessions obtained by running the example 'example03_correlation.m' 
load('maps8sessions','C');             % loads 16 correlations maps
load('allen_brain_atlas.mat','atlas');   % loads the Allen Mouse CCF


% compute statistics
[mapMean, mapTscore, mapPvalue]=map_statistics(C);


%%  Data visualization of statistical maps from multi-session (registered)
close all
figure(1)

hg=fspecial('gauss',7,1.5);
planes=[150,155,160,170,180,190,200];
nplanes=length(planes);
for i=1:nplanes
    plane=planes(i);
    
    subplot(nplanes,2,(i*2)-1);
    imagesc(squeeze(mapMean(plane,:,:)));
    draw_borders(atlas,'coronal',plane);
    colormap jet;
    caxis([-0.2 0.2]);
    
    subplot(nplanes,2,i*2);
    mask=filter2(hg,squeeze(abs(mapPvalue(plane,:,:))<0.05));
    mask=mask.*squeeze(atlas.Regions(plane,:,:)>1);  %mask outside brain
    imagesc(squeeze(mapMean(plane,:,:)).*mask);
    draw_borders(atlas,'coronal',plane);
    colormap jet;
    caxis([-0.2 0.2]);
end

subplot(nplanes,2,1); title('No threshold');
subplot(nplanes,2,2); title('p<0.05');



