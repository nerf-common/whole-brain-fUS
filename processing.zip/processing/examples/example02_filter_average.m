% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Filter and averages 6 scans of the same session.
% the file names in this example are scan1, scan2 .. scan6
average=0; 
for i=1:6
    load(['scan' num2str(i)],'scanfus');
    outliers=data_stability(scanfus);
    acc=input('accepted? [y/n] ','s');
    if acc=='y'
     scanfusRej=image_rejection(scanfus,outliers);
     average=average+scanfusRej.Data;
    end
end

% Change the data in the structure scanfus and save it.
scanfus.Data= average;
save( 'sessionAverage', 'scanfus','-v6');
