% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Perform Pearson's correlation on dataset 
% loads the average scan of one session. This file is the result of the example 'example02_filter_average.m'
load('sessionAverage.mat','scanfus'); 

T1= 34;         % Start of the stimulus.
T2= 44;          % End of the stimulus.
mapOriginal=map_correlation(scanfus, T1, T2);

%% Data visualization of 20 Doppler planes (not registered)
close all
figure(1);
[nz,nx,np,nt]=size(scanfus.Data); % data dimensions
for i=1:np
    subplot(4,5,i); 
    imagesc(mean(scanfus.Data(:,:,i,:),4).^0.25); 
    TITLE = sprintf('Plane %d', i);
    title (TITLE);
    axis off;
    caxis([25 100]);
end
colormap gray;
suptitle('Individual uDoppler images of the scan');

%% Data visualization of 20 correlation planes (not registered)
figure(2);
for i=1:np
    subplot(4,5,i); 
    imagesc(mapOriginal.Data(:,:,i)); 
    TITLE = sprintf('Plane %d', i);
    title (TITLE);
    axis off;
    caxis([-0.4 0.4]);
end
colormap (jet);
suptitle('Correlation maps of each individual plane');


%% Register the map and the averged scan with the atlas
load('Transformation','Transf');         % affine transformation. Result of example01_registering.m
load('allen_brain_atlas.mat','atlas');    % atlas structure
mapRegistered  = register_data(atlas,mapOriginal,Transf);

%% Data visualization of registered data 
PlaneSag=160;   % Sagittal plane
PlaneTra=25;    % Transversal plane
PlaneCor=190;   % Coronal plane

% Sagittal view
figure(3)
imagesc(squeeze(mapRegistered(:,:,PlaneSag))');
draw_borders(atlas,'sagittal',PlaneSag);
TITLE = sprintf('Sagittal view - Plane %d', PlaneSag);title (TITLE);
caxis([-0.4 0.4]);
axis equal; axis tight;
colormap jet;

% Transversal view
figure(4)
imagesc(squeeze(mapRegistered(:,PlaneTra,:)));
draw_borders(atlas,'transversal',PlaneTra);
TITLE = sprintf('Transversal view - Plane %d', PlaneTra);title (TITLE);
caxis([-0.4 0.4]);
axis equal; axis tight;
colormap jet;

% Coronal view
figure(5)
imagesc(squeeze(mapRegistered(PlaneCor,:,:)));
draw_borders(atlas,'coronal',PlaneCor);
TITLE = sprintf('Coronal view - Plane %d', PlaneCor);title (TITLE);
caxis([-0.4 0.4]);
axis equal; axis tight;
colormap jet;





