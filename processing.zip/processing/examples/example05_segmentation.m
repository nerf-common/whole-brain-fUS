% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Registration and segmentation of the functional scans
load('sessionAverage.mat');   % loads the average scan of one session. This file is the result of the example 'example02_filter_average.m'
load('Transformation.mat');   % loads the transformation matrix file result of 'example01_registering.m'
load('allen_brain_atlas.mat');    % loads the Allen Mouse CCF

% Registration and segmentation of the functional scans with the Allen Mouse CCF
scanfusSegmented=segmentation_ccf(atlas,scanfus,Transf);

% Selection of a subset of brain regions listed in 'list_selected_regions.txt'.
regionSelection=select_brain_regions(atlas,'list_selected_regions.txt',scanfusSegmented);

%% Visualization of the z-score time-courses for individual brain regions (registered)
close all
figure(1);
% in this example we averaged both hemispheres
imagesc(regionSelection.Left+regionSelection.Right); 
title (' z-score ');
xlabel('Time (images)');
ylabel('Regions')
caxis([-6 6]);
colormap (jet)