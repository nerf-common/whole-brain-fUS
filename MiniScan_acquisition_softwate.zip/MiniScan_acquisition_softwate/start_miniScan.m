% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

% MODIFY:  set the vantage path
VANTAGEPATH='C:\02_Vantage\Vantage-3.4.0-1711281030';

% MODIFY:  set the version
VANTAGEVERSION='VER340'; % options are: 'VER307' 'VER340'  'VER343' 'Emulator'


% Sart vantage software and move to current folder
miniscanPath=pwd;

if ~strcmp(VANTAGEVERSION,'Emulator')
    setenv('MINISCAN',miniscanPath);
    cd(VANTAGEPATH');
    disp('activate version');
    activate;
    miniscanPath=getenv('MINISCAN');
    cd(miniscanPath);
end

% add path
addpath([miniscanPath '\acquisition']);
addpath([miniscanPath '\acquisition\mexfiles']);
addpath([miniscanPath '\acquisition\noclass']);
addpath([miniscanPath '\acquisition\versions\' VANTAGEVERSION]);

global SCAN;
SCAN=miniScan();
