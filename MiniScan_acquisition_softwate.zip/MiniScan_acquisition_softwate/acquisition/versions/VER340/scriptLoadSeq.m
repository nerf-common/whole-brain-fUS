%TMPVERSAVE=saveUserVariables(whos);

SetSeq;
SetHV(S.HVset,S);

%recuperateVars(TMPVERSAVE);
%clear TMPVERSAVE
