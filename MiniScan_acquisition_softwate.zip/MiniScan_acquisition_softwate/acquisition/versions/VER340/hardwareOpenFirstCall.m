function retour=hardwareOpenFirstCall()
retour=1; % bonction bidon pour compat 321 vers 340
end