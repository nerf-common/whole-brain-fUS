
function SetHV(hv,S)
% should be a subset of the range that setTpcProfileHighVoltage() uses.
hvmin=0;
hvmax=S.Trans.maxHighVoltage;

if hv < hvmin, hv = hvmin; end
if hv > hvmax, hv = hvmax; end
% Attempt to set high voltage.  On error, setTpcProfileHighVoltage() returns voltage range minimum.
[result, hvset] = setTpcProfileHighVoltage(hv,1);
pause(0.2);
if ~strcmpi(result, 'Success')
    error('ERROR!  Failed to set Verasonics TPC high voltage for profile 1 because \"%s\".', result);
end
end