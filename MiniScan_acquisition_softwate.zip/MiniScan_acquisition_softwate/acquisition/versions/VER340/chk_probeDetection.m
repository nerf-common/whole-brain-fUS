function chk_probeDetection( connector)
% connector is usualy Resource.Parameters.connector.
result = vdasScanheadSelect(connector,0);
if ~strcmpi(result, 'SUCCESS'), error('VSX: Failed to select scanhead because "%s".\n', result); end
end