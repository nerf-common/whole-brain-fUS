function TMPVERSAVE=saveUserVariables(vars)

ListVer={'Control';  'Event';  'HARD';  'HWactiveCG';  'ID'; 
    'Id1';  'LogData';  'Media';  'Presence';  'Process';  
    'RcvProfile';  'Receive';  'RequiredStructs';  'Resource'; 
    'Result';  'S';   'Selected';  'SeqControl';  'TGC';  'TPC';  
    'TW';  'TX';  'TXEvent';  'TXEventCheckh';  'Trans';  'UTA';
    'VDAS';  'VDASupdates';  'VSX_Control';  'XX';  'abwvLength'; 
    'action';  'activeBoards';  'activeCGnums';  
    'arbwaveTxLicenseIsValid';  'exit';  'extendedTxLicenseIsValid'; 
    'freeze';  'hardwareLicenseIsValid';  'hvDefault';  'hvMax'; 
    'hvMux';  'i';  'initialized';  'j';  'lastRcvData';  'maxADRate';
    'minADRate';  'n';  'numBoards';  'numRbufCols';  'p5ena'; 
    'probeConnected';  'probeName';  'profile5inUse';  'rBufSize'; 
    'reconLicenseIsValid';  'result';  'rloopButton';  'selectConnector'; 
    'sequencePeriod';  'shouldConvertLogData';  'simButton';  
    'simulationLicenseIsValid';  'sizeTransActive';  'sysClk';  
    'tElapsed';  'triggerLicenseIsValid';  'updateh';  'v64ena';  
    'vars';  'xx'; };

ns=0;
TMPVERSAVE=[];
for i=1:length(vars)
    ind = getnameidx(ListVer, vars(i).name);
    if ind>0
       ns=ns+1;
       TMPVERSAVE{ns}=vars(i).name;
       evalin('base', ['TMPVER',ListVer{ind},'=',ListVer{ind},';']); 
    end
end

