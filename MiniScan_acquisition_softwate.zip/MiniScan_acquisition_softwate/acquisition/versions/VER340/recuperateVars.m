function recuperateVars(TMPVERSAVE)

ListVer={'Control';  'Event';  'HARD';  'HWactiveCG';  'ID'; 
    'Id1';  'LogData';  'Media';  'Presence';  'Process';  
    'RcvProfile';  'Receive';  'RequiredStructs';  'Resource'; 
    'Result';  'S';   'Selected';  'SeqControl';  'TGC';  'TPC';  
    'TW';  'TX';  'TXEvent';  'TXEventCheckh';  'Trans';  'UTA';
    'VDAS';  'VDASupdates';  'VSX_Control';  'XX';  'abwvLength'; 
    'action';  'activeBoards';  'activeCGnums';  
    'arbwaveTxLicenseIsValid';  'exit';  'extendedTxLicenseIsValid'; 
    'freeze';  'hardwareLicenseIsValid';  'hvDefault';  'hvMax'; 
    'hvMux';  'i';  'initialized';  'j';  'lastRcvData';  'maxADRate';
    'minADRate';  'n';  'numBoards';  'numRbufCols';  'p5ena'; 
    'probeConnected';  'probeName';  'profile5inUse';  'rBufSize'; 
    'reconLicenseIsValid';  'result';  'rloopButton';  'selectConnector'; 
    'sequencePeriod';  'shouldConvertLogData';  'simButton';  
    'simulationLicenseIsValid';  'sizeTransActive';  'sysClk';  
    'tElapsed';  'triggerLicenseIsValid';  'updateh';  'v64ena';  
    'vars';  'xx'; };

for i=1:length(ListVer)
     evalin('base', ['clear ' ListVer{i},';']); 
end


for i=1:length(TMPVERSAVE)
       evalin('base', [TMPVERSAVE{i},'=','TMPVER',TMPVERSAVE{i},';']); 
       evalin('base', ['clear TMPVER',TMPVERSAVE{i},';']); 
end

end