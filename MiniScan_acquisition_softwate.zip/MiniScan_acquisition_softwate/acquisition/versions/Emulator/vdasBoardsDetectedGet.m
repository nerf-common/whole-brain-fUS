% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

function nbb=vdasBoardsDetectedGet
nbb=2;
end
