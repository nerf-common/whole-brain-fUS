% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

% Template of stpMotor class
% RENAME THIS FILE stpMotor.m 
% and replace in the folder /miniScan

% class must be named stpMotor
classdef stpMotor <  handle
    
    % only one public property is defined.
    properties
        Xmm=0;   % position of the motor encoder in mm this position 
    end          % must be changed at each movement of the motor.
    
    methods
        
        % constructor without parameters
        % method called by the constructor of miniScan
        function M=stpMotor()
          % enter constructor here    
        end
        
        % open  the motor
        % method called by the open Motor button
        % port is the string in the port field.
        function open(M,port)
           % enter initialization of the motor
        end
        
        % move the motor to position x in mm
        % method called by Move and the volumetric scanning.
        function moveA(M,x)
          % entre moving instructions
        end
        
        % stops the motor
        % method is called by the STOP button
        function STOP(M)
           % enter emergency stop instructions
        end
        
        % sets the current position as 0
        % method  called by the button Set origin 
        function resetOrigin(M)
           % enter reset instructions
        end
        
        % close the serial port
        % method called as a destructor
        function close(M)
          % close instructions
        end
    end
    
    % activate this event at each new position of the motor (optional)
    % the filed of the motor position is refreshed with the Xmm property.
    events
        newMotorPosition
    end
    
end

