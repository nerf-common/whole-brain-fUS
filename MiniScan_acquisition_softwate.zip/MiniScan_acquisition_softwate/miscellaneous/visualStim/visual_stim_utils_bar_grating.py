#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author : Théo Lambert (theo.lambert@grenoble-inp.org), NERF, Urban Lab
Adapted from an original code by Clare Dussaux, 2015
This experimental tool was created using PsychoPy3 Coder Interface (v3.1.2), April 17th 2019
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
from math import atan, degrees
from psychopy.tools.monitorunittools import pix2deg
import os  # handy system and path functions
import serial




class visualStimulator:

    """
    @summary: object to pilot the visual stimulations. See 'visual_stim.py' to
        set the parameters and use it.
    """


    def __init__(self, port, trigger, stop, path, filename, params, mode):

        """
        @summary: instanciation of the class with given parameters, see
            'visual_stim.py' for the details of 'params'. Create the windows
            on which the stimulations will be displayed once the object is
            created.
        @params:
            * port (string) : the serial port to receive fUSi control
            * trigger (int) : the value that will be sent through serial
            * path (string) : path to save the journal
            * filename (string) : the filename that will be given to the journal
            * params (dict) : the parameters for the visual stimulations
        """

        self.port = serial.Serial(port=port, baudrate=9600, timeout=3000)
        ####self.port.open()
        self.trigger = trigger
        self.stop = stop
        self.path = path
        self.params = params
        self.mode = mode
        self.wait = True
        os.system('mkdir '+path+os.sep)
        self.filename = path+os.sep+filename+data.getDateStr()+".txt"

        self.endExpNow = False  # flag for 'escape' or other condition => quit the exp

        if self.params['orientation'] == 'azimuth':
            ori = 90
        else:
            ori = 0

        # Setup the Window
        self.win = visual.Window(size=self.params['screen_resolution'], fullscr=False, screen=1, allowGUI=False, allowStencil=False,
            monitor="testMonitor", color=self.params['color_bg'], colorSpace='rgb',
            blendMode='avg', useFBO=True,
            )

        # store frame rate of monitor if we can measure it successfully
        self.params['framerate']=self.win.getActualFrameRate()
        if self.params['framerate']!=None:
            self.frameDur = 1.0/round(self.params['framerate'])
        else:
            self.frameDur = 1.0/60.0 # couldn't get a reliable measure so guess
        self.speed = self.params['speed']/self.params['framerate']#pixel/frame

        mytex = np.array([[-1, 1]])
        # creation of the grating
        self.grating = visual.GratingStim(win=self.win, name='grating',units='deg',
            tex=mytex, mask=None,
            ori=ori, pos=[0,0], size=[self.params['screen_resolution'][1], self.params['bar_width']], sf=self.params['sf'], phase=0,
            color=self.params['color_bar'], colorSpace='rgb', opacity=1,
            texRes=128, interpolate=False, depth=0.0)

        # saving the experimental parameters
        with open(self.filename, 'w') as dst:
            for key in self.params:
                dst.write(key+" "+str(self.params[key])+"\n")


    def start_stim(self):

        """
        @summary: start the visual stimulations. Once all visual stimulations
            are completed, wait until 'duration' before closing the window.
        """

        # set up handler to look after randomisation of conditions etc
        self.trials = data.TrialHandler(nReps=1, method='sequential',
            originPath=None, trialList=[None], seed=None, name='trials')
        self.thisTrial = self.trials.trialList[0]  # so we can initialise stimuli with some values

        # abbreviate parameter names if possible (e.g. rgb=thisTrial.rgb)
        if self.thisTrial != None:
            for paramName in self.thisTrial.keys():
                exec(paramName + '= thisTrial.' + paramName)

        # Initialize components for Routine "trial"
        trialClock = core.Clock()

        # Create some handy timers
        globalClock = core.Clock()  # to track the time since experiment started
        start = globalClock.getTime()
        routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine
        width_deg = degrees(atan(self.params['width']/self.params['distance']))

        for self.thisTrial in self.trials:
            currentLoop = self.trials
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if self.thisTrial != None:
                for paramName in self.thisTrial.keys():
                    exec(paramName + '= thisTrial.' + paramName)

            #------Prepare to start Routine "trial"-------
            t = 0
            trialClock.reset()  # clock
            frameN = -1
            #routineTimer.add((width_deg) / self.params['speed']+self.params['delay'])
            routineTimer.add(self.params['duration'])
            # update component parameters for each repeat
            # keep track of which components have finished
            trialComponents = []
            trialComponents.append(self.grating)
            for thisComponent in trialComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED

            #-------Start Routine "trial"-------
            continueRoutine = True
            if self.mode == 'normal':
                self.grating.pos=[-0.5*width_deg, 0]
            else:
                self.grating.pos=[0.5*width_deg, 0]
            t_tmp = trialClock.getTime()
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = trialClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame

                # *grating* updates
                if t - t_tmp > 1/self.params['freq']:
                    self.grating.tex = -self.grating.tex
                    t_tmp = t
                if t >= 0.0 and self.grating.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    self.grating.tStart = t  # underestimates by a little under one frame
                    self.grating.frameNStart = frameN  # exact frame index
                    self.grating.setAutoDraw(True)
                if self.grating.status == STARTED and t >= (0.0 + (30-self.win.monitorFramePeriod*0.75)): #most of one frame period left
                    self.grating.setAutoDraw(False)
                if self.grating.status == STARTED:  # only update if being drawn
                    if self.mode == 'normal':
                        self.grating.setPos([self.speed, 0], '+', log=False)
                    else:
                        self.grating.setPos([-self.speed, 0], '+', log=False)

                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished

                # check for quit (the Esc key)
                if event.getKeys(keyList=["escape"]): #or self.endExpNow
                    self.port.close()
                    core.quit()

                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    self.win.flip()

            #-------Ending Routine "trial"-------
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)

        self.win.color = self.params['color_bg']
        self.win.flip()
        self.win.flip()

        #while (globalClock.getTime() - start) < self.params['duration']: pass
        self.wait_for_serial()


    def wait_for_serial(self):

        """
        @summary: wait for the reception of 'trigger' on the serial port. Once
            it is received, start the visual stimulations.
        """

        wait = True
        while wait:
            val = self.port.read()
            print(ord(val), type(val))
            if ord(val) == ord(self.trigger):
                wait = False
                self.start_stim()
            if ord(val) == self.stop:
                self.port.close()
                self.win.close()
                core.quit()
                wait = False
