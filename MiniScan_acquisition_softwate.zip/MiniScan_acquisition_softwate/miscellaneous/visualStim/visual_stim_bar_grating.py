﻿"""
Author : Théo Lambert, NERF, Urban lab, April 17th 2019
User code interface to use the class coded in visual_stim_utils.py. You can set
here the parameters of the experiment.
"""


import visual_stim_utils_bar_grating as u
from psychopy.monitors import Monitor

# port connected to the fUSi
port = "COM4"

# path to where to store the data WARNING: for '\' put '\\'
path = ".\\data"

# filename where info will be logged
filename = "test"

# mode is either 'normal' or 'reverse' (bar moves in the other sense)
mode = 'normal'

# azimuth or elevation
orientation = 'elevation'

# byte to interpret as a fUSi instruction for starting the stimulations
trigger = 'T'

# byte to interpret as a fUSi instruction for stopping the experiment
stop = 1

# resolution of the host screen
screen_resolution = (1920,1080)

# width of the bar in pixels
bar_width = 35 #9

# temporal duration of the stimulus
duration = 6 # seconds

# speed/spatial frequency of the grating
speed = 0 #degrees/seconds
freq = 0.5 #Hz
spatial_frequency = 0.5

# color of the background in RGB
color_bg = [-1,-1,-1]

# color of the bar in RGB
color_bar = [1,1,1]

# specs of the monitor (in meters)
width = 0.60
distance = 0.6
####gamma = 2.4


params = {"screen_resolution":screen_resolution, "bar_width":bar_width, "speed":speed, "color_bg":color_bg, "color_bar":color_bar, "width":width, "distance":distance, "freq":freq, "orientation":orientation, "sf":spatial_frequency, "duration":duration}
#monitor = Monitor('main', width=width, distance=distance, gamma=gamma)
stim = u.visualStimulator(port, trigger, stop, path, filename, params, mode)

### uncomment the next line if you want to do stimulation without serial control
### and comment the line just after ("stim.wait_for_serial()")
#stim.start_stim()

stim.wait_for_serial()
