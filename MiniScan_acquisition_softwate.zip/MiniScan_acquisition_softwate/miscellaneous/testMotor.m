% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

% Test of the motor.

addpath([pwd '\..\miniScan']);
s.open('com1')
s.moveA(10)
s.moveA(0)
s.close();