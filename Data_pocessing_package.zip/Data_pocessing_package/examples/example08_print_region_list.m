% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020

%% Generate information of all brain regions from the Allen Mouse CCF

load('allen_brain_atlas.mat'); % loads the Allen Mouse CCF

print_region_list(atlas,'list_selected_regions.txt');
% Outputs are in files:
%   list_selected_brain_regions_number.txt    index number
%   list_selected_brain_regions_alpha.txt     alphabetic order
%   list_selected_brain_regions_volume.txt    total volume
 
print_region_list(atlas);
% Outputs are in files:
%   atlas_number.txt    index number
%   atlas_alpha.txt     alphabetic order
%   atlas_volume.txt    total volume
