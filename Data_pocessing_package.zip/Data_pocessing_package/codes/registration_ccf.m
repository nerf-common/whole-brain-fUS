% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020
%
% Opens the graphical user interface to register data with the Allen Mouse Common Coordinate Framework
%
% registration_ccf(atlas, scananatomy)
% registration_ccf(atlas, scananatomy, InitialTransf)
%   atlas, the Allen Mouse Common Coordinate Framework, provided in the "allen_brain_atlas.mat" file,
%   scananatomy, a fus-strucure of type volume containing the anatomical scan,
%   InitialTransf, (optional) Affine transformation structure obtained from a 
%                previous execution of registration_ccf. If this parameter is present,
%                the data is transformed with the InitalTransform before starting 
%                the manual registration. 

% A structure Transf is saved in a file "Transformation.mat". This structure 
% contains the affine transformation matrix (field M) and the view size (field size).
%
% Example:  'example01_registering.m'
%%
classdef registration_ccf < handle
    
    properties
        H
        ms1
        ms2
        DataNoScale
        scale
        r1
        r2
        r3
        Trot
        TF
        T0
        mapRegions
        mapHistology
        mapVascular
    end
    
    properties (Access=protected )
        im1
        im2
        im3
        im4
        im5
        im6
        line1x
        line1y
        line2x
        line2y
        line3x
        line3y
        line4x
        line4y
        line5x
        line5y
        line6x
        line6y
        linmap
        hlinesS
        hlinesC
        hlinesT
    end
    
    methods
        function R=registration_ccf(atlas,scananatomy, initialTransf)
            
            % initial rotation
            if nargin==3
                R.T0=initialTransf.M;
            else
                R.T0=eye(4);
            end
            
            % equalize images
            scananatomy.Data=equalizeImages(scananatomy.Data);
            
            R.DataNoScale=scananatomy.Data;
            
            %data preparation
            tmp=interpolate3D(atlas,scananatomy);
            R.ms2=mapscan(tmp.Data,hot(128),'fix');
            R.ms2.caxis=[0.1 0.8];
            
            R.mapHistology=mapscan(atlas.Histology,gray(256),'index');
            R.mapVascular=mapscan(atlas.Vascular,gray(256),'auto');
            R.mapRegions=mapscan(atlas.Regions,atlas.infoRegions.rgb,'index');
            R.ms1=R.mapVascular;
            
            R.H=guihandles(open('figviewscan.fig'));  % load GUI figure
            
            % set sliders
            R.H.slider1.Min=1;
            R.H.slider2.Min=1;
            R.H.slider3.Min=1;
            R.H.slider1.Max=R.ms1.nx;
            R.H.slider2.Max=R.ms1.ny;
            R.H.slider3.Max=R.ms1.nz;
            R.H.slider1.Value=R.ms1.x0;
            R.H.slider2.Value=R.ms1.y0;
            R.H.slider3.Value=R.ms1.z0;
            R.H.edit1.String=num2str(R.ms1.x0);      % set planes
            R.H.edit2.String=num2str(R.ms1.y0);
            R.H.edit3.String=num2str(R.ms1.z0);
            R.H.caxis.String=num2str(R.ms2.caxis);
            
            R.H.colormap.String='hot';              % set defoult colormap
            
            % create and init images to 0 in axes
            R.im1=imagesc(zeros(R.ms1.ny,R.ms1.nz),'parent',R.H.axes1);
            R.im2=imagesc(zeros(R.ms1.nx,R.ms1.nz),'parent',R.H.axes2);
            R.im3=imagesc(zeros(R.ms1.nx,R.ms1.ny),'parent',R.H.axes3);
            R.im4=imagesc(zeros(R.ms1.ny,R.ms1.nz),'parent',R.H.axes4);
            R.im5=imagesc(zeros(R.ms1.nx,R.ms1.nz),'parent',R.H.axes5);
            R.im6=imagesc(zeros(R.ms1.nx,R.ms1.ny),'parent',R.H.axes6);
            axis(R.H.axes1,'equal','tight');
            axis(R.H.axes2,'equal','tight');
            axis(R.H.axes3,'equal','tight');
            axis(R.H.axes4,'equal','tight');
            axis(R.H.axes5,'equal','tight');
            axis(R.H.axes6,'equal','tight');
            
            % init cross hairs lines for the 6 axes. 
            R.line1x= line([0,R.ms1.nz],[R.ms1.y0,R.ms1.y0],'Parent',R.H.axes1,'Color',[1 1 1]);
            R.line1y= line([R.ms1.z0,R.ms1.z0],[0,R.ms1.ny],'Parent',R.H.axes1,'Color',[1 1 1]);
            R.line2x= line([0,R.ms1.nz],[R.ms1.x0,R.ms1.x0],'Parent',R.H.axes2,'Color',[1 1 1]);
            R.line2y= line([R.ms1.z0,R.ms1.z0],[0,R.ms1.nx],'Parent',R.H.axes2,'Color',[1 1 1]);
            R.line3x= line([0,R.ms1.nx],[R.ms1.x0,R.ms1.y0],'Parent',R.H.axes3,'Color',[1 1 1]);
            R.line3y= line([R.ms1.x0,R.ms1.x0],[0,R.ms1.ny],'Parent',R.H.axes3,'Color',[1 1 1]);
            R.line4x= line([0,R.ms1.nz],[R.ms1.y0,R.ms1.y0],'Parent',R.H.axes4,'Color',[1 1 1]);
            R.line4y= line([R.ms1.z0,R.ms1.z0],[0,R.ms1.ny],'Parent',R.H.axes4,'Color',[1 1 1]);
            R.line5x= line([0,R.ms1.nz],[R.ms1.x0,R.ms1.x0],'Parent',R.H.axes5,'Color',[1 1 1]);
            R.line5y= line([R.ms1.z0,R.ms1.z0],[0,R.ms1.nx],'Parent',R.H.axes5,'Color',[1 1 1]);
            R.line6x= line([0,R.ms1.nx],[R.ms1.y0,R.ms1.y0],'Parent',R.H.axes6,'Color',[1 1 1]);
            R.line6y= line([R.ms1.x0,R.ms1.x0],[0,R.ms1.ny],'Parent',R.H.axes6,'Color',[1 1 1]);
            
            % set callbacks
            set(R.H.colormap,        'Callback', {@setcolormap,R});
            set(R.H.caxis,           'Callback', {@setcaxis,R});
            set(R.H.slider1,         'Callback', {@readslider, R});
            set(R.H.slider2,         'Callback', {@readslider, R});
            set(R.H.slider3,         'Callback', {@readslider, R});
            set(R.H.edit1,           'Callback', {@readvalues, R});
            set(R.H.edit2,           'Callback', {@readvalues, R});
            set(R.H.edit3,           'Callback', {@readvalues, R});
            set(R.H.colormap,        'Callback', {@colormap, R});
            set(R.H.caxis,           'Callback', {@coloraxis, R});
            set(R.H.apply,           'Callback', {@applyCall, R});
            set(R.H.scaleX,          'Callback', {@applyRescale,R});
            set(R.H.scaleY,          'Callback', {@applyRescale,R});
            set(R.H.scaleZ,          'Callback', {@applyRescale,R});
            set(R.H.save,            'Callback', {@saveCall, R});
            set(R.H.comparaVascular, 'Callback', {@comparativeAtlas, R,R.mapVascular});
            set(R.H.comparaHistology,'Callback', {@comparativeAtlas, R,R.mapHistology});
            set(R.H.comparaRegions,  'Callback', {@comparativeAtlas, R,R.mapRegions});
            
            % listener of refresh
            addlistener(R,'viewrefreshed', @(src,event)activemove(src,event,R));
            
            % other inits
            R.linmap=atlas.Lines;
            R.hlinesS=[];
            R.hlinesC=[];
            R.hlinesT=[];
            R.scale=[1 1 1];
            R.Trot=eye(4);
            R.DataNoScale=R.ms2.D;
            
            % apply rotation and refresh.
            R.restartMove();
            R.apply();
            R.refresh();
        end
        
        % enables to drag the image
        function restartMove(R)
            R.r1=moveimage(R.H.axes4);
            R.r2=moveimage(R.H.axes5);
            R.r3=moveimage(R.H.axes6);
        end
        
        % apply partial rotation to all volume
        function apply(R)
            tot=build3DrotationMatrix(R); % compose 3D partial rotation
            R.Trot=R.Trot*tot;            % full rotation
            
            % scale
            TS=eye(4);
            TS(1,1)=R.scale(1); TS(2,2)=R.scale(2); TS(3,3)=R.scale(3);
            R.TF=R.T0*TS*R.Trot;   % full transform
            
            m=affine3d(R.TF);
            ref=imref3d(size(R.ms1.D));
            
            R.ms2.setData(imwarp(R.DataNoScale,m,'OutputView',ref));
            
            R.r1.T0=eye(3);
            R.r2.T0=eye(3);
            R.r3.T0=eye(3);
        end
        
        % refresh all the figure. 
        function  refresh(V)
            ms1=V.ms1;
            ms2=V.ms2;
            
            [a1,a2,a3]=ms1.cuts();
            
            V.im1.CData=a1;
            V.im2.CData=a2;
            V.im3.CData=permute(a3,[2,1,3]);
            
            [a1,a2,a3]=ms2.cuts();
            
            V.im4.CData=a1;
            V.im5.CData=a2;
            V.im6.CData=permute(a3,[2,1,3]);
            
            V.line1x.XData= [0,ms1.nz];      V.line1x.YData=[ms1.y0,ms1.y0];
            V.line1y.XData= [ms1.z0,ms1.z0]; V.line1y.YData=[0,ms1.ny];
            
            V.line2x.XData= [0,ms1.nz];      V.line2x.YData=[ms1.x0,ms1.x0];
            V.line2y.XData= [ms1.z0,ms1.z0]; V.line2y.YData=[0,ms1.nx];
            
            V.line3x.XData= [0,ms1.nx];      V.line3x.YData=[ms1.y0,ms1.y0];
            V.line3y.XData= [ms1.x0,ms1.x0]; V.line3y.YData=[0,ms1.ny];
            
            V.line4x.XData= [0,ms1.nz];      V.line4x.YData=[ms1.y0,ms1.y0];
            V.line4y.XData= [ms1.z0,ms1.z0]; V.line4y.YData=[0,ms1.ny];
            
            V.line5x.XData= [0,ms1.nz];      V.line5x.YData=[ms1.x0,ms1.x0];
            V.line5y.XData= [ms1.z0,ms1.z0]; V.line5y.YData=[0,ms1.nx];
            
            V.line6x.XData= [0,ms1.nx];      V.line6x.YData=[ms1.y0,ms1.y0];
            V.line6y.XData= [ms1.x0,ms1.x0]; V.line6y.YData=[0,ms1.ny];
            
            V.H.slider1.Value=V.ms1.x0; V.H.edit1.String=num2str(V.ms1.x0);
            V.H.slider2.Value=V.ms1.y0; V.H.edit2.String=num2str(V.ms1.y0);
            V.H.slider3.Value=V.ms1.z0; V.H.edit3.String=num2str(V.ms1.z0);
            
            % include lines objects
            delete(V.hlinesC);
            V.hlinesC=addLines(V.H.axes4,V.linmap.Cor,V.ms1.x0);
            delete(V.hlinesT);
            V.hlinesT=addLines(V.H.axes5,V.linmap.Tra,V.ms1.y0);
            delete(V.hlinesS);
            V.hlinesS=addLines(V.H.axes6,V.linmap.Sag,V.ms1.z0);
            
            drawnow;
            V.notify('viewrefreshed');
        end
    end
    
    events
        viewrefreshed
    end
end

% changes the atlas to compare (vascular, histology or regions)
function comparativeAtlas(~,~,R,map)
R.ms1=map;
R.refresh();
end


% activates the drag of the images
function activemove(~,~,R)
R.restartMove();
end

% changes colormap
function colormap(h,~,R)
R.ms2.cmap=evalin('base',h.String);
R.refresh();
end

% changest coloraxis
function coloraxis(h, ~,R)
R.ms2.caxis=str2num(h.String);
R.refresh();
end


% rescale 
function applyRescale(~, ~,R)
R.scale=[ str2double(get(R.H.scaleY,'String')), str2double(get(R.H.scaleX,'String')),str2double(get(R.H.scaleZ,'String'))] ;
R.apply();
R.refresh();
set (R.H.figure1,'Pointer','arrow');
end

function applyCall(~, ~,R)
set (R.H.figure1,'Pointer','watch'); drawnow;
R.apply();
R.refresh();
set (R.H.figure1,'Pointer','arrow');
end

function saveCall(~,~,R)
Transf.M= R.TF;
Transf.size=size(R.ms1.D);
save('Transformation','Transf');
end

% normalize data for view
function DataNorm=equalizeImages(Data)

DataNorm=Data-min(Data(:));
DataNorm=DataNorm./max(DataNorm(:));
m=median(DataNorm(:));
comp=-2/log2(m);
DataNorm=DataNorm.^comp;
DataNorm=DataNorm-min(DataNorm(:));
DataNorm=DataNorm./max(DataNorm(:));
end


% auxiliar functions
function tot=build3DrotationMatrix(R)
tot=eye(4);
tmpx=R.r1.T0;
tmpx(1:2,1:2)=tmpx(1:2,1:2)'; tmpx(3,1:2)=fliplr(tmpx(3,1:2));
tmp=[tmpx(1,:); zeros(1,3); tmpx(2:end,:)];
tmp=[tmp(:,1), zeros(4,1), tmp(:,2:end)];
tmp(2,2)=1; tot=tot*tmp;

tmpx=R.r2.T0;
tmpx(1:2,1:2)=tmpx(1:2,1:2)'; tmpx(3,1:2)=fliplr(tmpx(3,1:2));
tmp=[ zeros(1,3); tmpx(1:end,:)];
tmp=[ zeros(4,1), tmp(:,1:end)];
tmp(1,1)=1; tot=tot*tmp;

tmpx=R.r3.T0;
tmpx(1:2,1:2)=tmpx(1:2,1:2)'; tmpx(3,1:2)=fliplr(tmpx(3,1:2));
tmp=[tmpx(1:2,:); zeros(1,3); tmpx(3:end,:)];
tmp=[tmp(:,1:2), zeros(4,1), tmp(:,3:end)];
tmp(3,3)=1; tot=tot*tmp;
end

function  setcaxis(h, ~,V)
V.ms2.caxis=str2double(h.String);
refresh(V);
end

function  setcolormap(h, ~,V)
eval(['tmp=' h.String '(128);']);
V.ms2.cmap=tmp;
refresh(V);
end

function  readslider(~, ~,V)
V.ms1.x0=round(V.H.slider1.Value);
V.ms1.y0=round(V.H.slider2.Value);
V.ms1.z0=round(V.H.slider3.Value);
V.ms2.x0=round(V.H.slider1.Value);
V.ms2.y0=round(V.H.slider2.Value);
V.ms2.z0=round(V.H.slider3.Value);
V.refresh();
end

function  readvalues(~, ~,V)
px=round(str2double(V.H.edit1.String));
py=round(str2double(V.H.edit2.String));
pz=round(str2double(V.H.edit3.String));
if px>1 && px<V.ms1.nx, V.ms1.x0=px; V.ms2.x0=px; end
if py>1 && py<V.ms1.ny, V.ms1.y0=py; V.ms2.y0=py; end
if pz>1 && pz<V.ms1.nz, V.ms1.z0=pz; V.ms2.z0=pz; end
refresh(V);
end

% draw border lines
function h=addLines(ax,LL,ip)
L=LL{ip};
hold(ax,'on');
nb=length(L);
h=gobjects(nb,1);
for ib=1:nb
    x=L{ib};
    h(ib)=plot(ax,x(:,2),x(:,1),'w:');        % change the color trae line etc here!
end
hold(ax,'off');
end

