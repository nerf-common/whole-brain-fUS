% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020
%
% Statistic analysis of the activity maps for multiple sessions
%
% [mapMean, mapTscore, mapPvalue]=map_statistics(C)
%   C    4D matrix (x,y,z,sessions) obtained using
%        the function example03_correlation for each session.
%   mapMean   3D matrix  average fo the maps over the sessions
%   mapTscore 3D matrix  t-score in each voxel
%   mapPvalue 3D matrix  p-value in each voxel
%
% Example! example06_multisession_map.m
%%
function [mapMean, mapTscore, mapPvalue]=map_statistics(C)
NumberSessions=size(C,4);
mapMean=mean(C,4);
mapStd=std(C,[],4)./sqrt(NumberSessions);
mapTscore=mapMean./mapStd;
mapPvalue= 1- tcdf(mapTscore,NumberSessions);
end