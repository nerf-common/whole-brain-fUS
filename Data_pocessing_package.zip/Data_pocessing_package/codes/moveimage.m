% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Mace Lab  - Max Planck institute of Neurobiology
% Authors:  G. MONTALDO, E. MACE
% Review & test: C.BRUNNER, M. GRILLET
% September 2020
%
% Internal class, Moves the image placed in an axes object 
% Returns the affine transformation in the T0 propertie.
% Uses two callbacks to the mouse:  
%   left button down = move.
%   rigth button down = rotate.
% 
% example:
%	h=figure();
%   imagesc(rand(100));
%   ax=h.Children;
%   moveimage(ax);
%%
classdef moveimage < handle
    
   properties
        a         % original image data
        at        % moved image data
        T0        % affine transformation 
   end
    
   properties(Access=protected )
        himage
        figure
        flagmove
        axes
        v0
        v1
        T1
        ref
        alfa
        dv
   end
    
    methods  
        function M=moveimage(axes)
            M.himage=searchImageInChildren(axes);
            M.figure=axes.Parent;
            M.axes=axes;
            M.a=M.himage.CData;
            M.at=M.himage.CData;
            
            M.ref= imref2d(size(M.a));
            
            M.T0=eye(3);
            M.T1=eye(3);
            M.v0=zeros(1,2);
            M.v1=zeros(1,2);
            M.dv=zeros(1,2);
            M.alfa=0;     
            M.flagmove=0;
            set(M.himage,'ButtonDownFcn',{@startrotation, M});
        end
           
        function refresh(M)
             M.himage.CData=M.at; % refresh image
        end
   
    end
    
    
    
 
end

% sets the callbacks of the mause to start rotation-translation
function startrotation(~,~, M)
set (M.figure, 'WindowButtonUpFcn',    {@mouseUp,     M});
set (M.figure, 'WindowButtonDownFcn',  {@mouseDown,   M});
set (M.figure, 'WindowButtonMotionFcn',{@mouseMove,   M});
set (M.figure,'Pointer','hand');
end



% callbacks mouse functions
function mouseUp (~,~,M)
M.flagmove=0;     % disable movement
M.T0=M.T0*M.T1; 
M.T1=eye(3);
M.v0=zeros(1,2);
M.v1=zeros(1,2);
M.dv=zeros(1,2);
M.alfa=0;
end

% set callbacks of the mouse to stops rotation-translation 
function mouseDown (~,~, M)
C0 = get (M.axes, 'CurrentPoint');
if isPointerInAxis(M.axes) 
   M.v0=C0(1,1:2);
   M.flagmove=1;  %enable movement
else
  set (M.figure, 'WindowButtonUpFcn',    '');
  set (M.figure, 'WindowButtonDownFcn',  '');
  set (M.figure, 'WindowButtonMotionFcn','');
  set (M.figure,'Pointer','arrow');
end
end

% call at each movement of the mouse
function mouseMove (~,~, M)

% detect if the mouse is moving inside the figure
if(isPointerInAxis(M.axes))
    set (M.figure,'Pointer','hand');
else
    set (M.figure, 'WindowButtonUpFcn',    '');
    set (M.figure, 'WindowButtonDownFcn',  '');
    set (M.figure, 'WindowButtonMotionFcn','');
    set(M.figure,'Pointer','arrow'); 
end

% if movement is activate drag the image
if  M.flagmove==1
    C0 = get (gca, 'CurrentPoint');
    M.v1=C0(1,1:2);
    M.dv=M.v1-M.v0;
    
    tmp0=M.v0(1)+sqrt(-1)*M.v0(2);
    tmp1=M.v1(1)-sqrt(-1)*M.v1(2);
    M.alfa=angle(tmp0*tmp1)*180/pi;
    
    if strcmp( M.figure.SelectionType,'alt')      %  right button = rotation
        M.T1=rotz(M.alfa);
    else                                          % left button = translatin
        M.T1=eye(3); M.T1(3,1:2)=M.dv;
    end
    m=affine2d(M.T0*M.T1);
    M.at=imwarp(M.a,m,'OutputView',M.ref);    
    M.refresh();
    
end
end

% auxiliar functions 
function h=searchImageInChildren(axes)
isit=0; 
for i=1:length(axes.Children)
     if isa(axes.Children(i),'matlab.graphics.primitive.Image')       
        isit=i;
     end
end
if isit==0
   error('no image in children of this axis');
end
h=axes.Children(isit);
end


% detect if the pointer is inside the figure area
function a=isPointerInAxis(axes)
 C0 = get (axes, 'CurrentPoint');  
 a= C0(1,1)>axes.XLim(1) && C0(1,1)<axes.XLim(2) && C0(1,2)>axes.YLim(1) && C0(1,2)<axes.YLim(2);
end

