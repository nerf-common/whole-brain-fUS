% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

% MODIFY:  set the vantage path
VANTAGEPATH='C:\Vantage\Vantage-3.4.3-1807021300';
% MODIFY:  set the version
VANTAGEVERSION='Emulator'; % options are: 'VER307' 'VER340'  'VER343' 'Emulator'


% Sart vantage software and move to current folder
acquisitionPath=[pwd '\acquisition'];

if ~strcmp(VANTAGEVERSION,'Emulator')
    setenv('MINISCAN',acquisitionPath);
    cd(VANTAGEPATH');
    disp('activate version 3.4.3');
    activate;
    acquisitionPath=getenv('MINISCAN');
end

% add path
addpath( acquisitionPath);
addpath([acquisitionPath '\mexfiles']);
addpath([acquisitionPath '\noclass']);
addpath([acquisitionPath '\versions\' VANTAGEVERSION]);

global SCAN;
SCAN=miniScan();
