% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

% Motor class for a zaber T-LSM100A.

classdef stpMotor <  handle
    
    properties
        Xmm=0;     % position of the motor encoder in mm
    end
    
    properties (Access=private)
        mmstep=4.794e-5;  % motor step size  in mm
        port;    % serial port
        motorDetected;
    end
    
    methods
        function M=stpMotor()
            M.motorDetected=0;
        end
        
        function open(M,port)
            if M.motorDetected==1, fclose(M.port); end
            M.port=serial(port,'BaudRate',9600);
            set(M.port,'BytesAvailableFcnCount',6);
            set(M.port,'BytesAvailableFcnMode','byte');
            
            fopen(M.port);
            if  ~strcmp(M.port.status,'open')
                error('unable to opent port');
            end
            
            % control if the Zaber motor is connected
            cmd=data2cmd(1,50,0);
            fwrite(M.port,cmd);
            warning('OFF');
            x=fread(M.port,6);
            warning('ON');
            if length(x)== 6
                [~,echocmd,~]=cmd2data(x);
                if echocmd==50
                    M.motorDetected=1;
                    set(M.port,'BytesAvailableFcn',{@readBuffer,M});
                end
            end
            
            if M.motorDetected==0, fclose(M.port); end
            fprintf('motor detection %d\n',M.motorDetected);
            resetOrigin(M);
        end
        
        % move the motor to position A
        function moveA(M,x)
            if M.motorDetected==0, return, end
            xs=M.mm2stp(x);
            cmd=data2cmd(1,20,xs);
            fwrite(M.port,cmd);
            timeout=0;
            while abs(M.Xmm-x)>0.1 && timeout<200
                pause(0.1)
                timeout=timeout+1;
            end
        end
        
        % stops the motor
        function STOP(M)
            if M.motorDetected==0, return, end
            cmd=data2cmd(1,23,0);
            fwrite(M.port,cmd);
            pause(0.2);
        end
        
        % sets the current position as 0
        function resetOrigin(M)
            if M.motorDetected==0, return, end
            xstp=M.mm2stp(0);
            cmd=data2cmd(1,45,xstp);
            fwrite(M.port,cmd);
            pause(0.2);
        end
        
        % close the serial port
        function close(M)
            if M.motorDetected==0, return, end
            fclose(M.port);
        end
    end
    
    
    methods (Access= private)
        function x=stp2mm(M,s)
            x=double(s)*M.mmstep-50;
        end
        
        function s=mm2stp(M,x)
            s=round((x+50)/M.mmstep);
        end
    end
    
    % this event is triggered at each changes answer of the motor
    events
        newMotorPosition
    end
    
end

% this function is activated each time the serial port
% receives 6 bytes (an answer of the motor)
function readBuffer(port,~,M)
while port.BytesAvailable>=6
    x=fread(port,6);
    [~,~,data]=cmd2data(x);
    M.Xmm= M.stp2mm(data);
    notify(M,'newMotorPosition');
end
end

% auxiliar function converts a command in numeric data
function [dev,command,data]=cmd2data(cmd)
dev=uint8(cmd(1));
command=uint8(cmd(2));
data=typecast(uint8(cmd(3:6)),'int32');
end

% auxiliar function converts a numeric command in a string uint8
function cmd=data2cmd(dev,comand,data)
x=int32(data);
x=typecast(x,'uint8');
cmd(1)=uint8(dev);
cmd(2)=uint8(comand);
cmd(3:6)=x(:);
end

