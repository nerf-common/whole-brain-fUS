% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

function sequenceMem = vdasSequencerRamGet()
sequenceMem=1e6;
end

