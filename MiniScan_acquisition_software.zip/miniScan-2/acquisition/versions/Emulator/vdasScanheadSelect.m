% Urban Lab - NERF empowered by imec, KU Leuven and VIB
% Author:  G. MONTALDO.
% September 2020

function result = vdasScanheadSelect(connector,x)
result='SUCCESS';
end