%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter list of the miniScan system
% NERF lab  december 2020
% Author: G. Montaldo
%
% Users can edit and modify all these parameters. To load a new set of
% parameters use the method SCAN.loadUserParameters(filename)
% >> SCAN.loadUserParameters('userParameters');
%
% WARNING! the parameters: HVset, compoundAngles, compoundAverage 
% compoundAverageCoef, compoundFrameRate, emissionLenght, modifies the 
% EMISSION POWER. A high emission power can destroy the probe.   
% be special carefully with the modifications of HVset. The system can send
% up to 100V and destroy the probe. 
% Lines 68 to 80 includes a minimal control of the power that must be
% adjusted for each probe.
% We discharged from all responsibility in case of damages in the probe
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% transducer parameters
par.probeFreq=15.625;                       % Central frequency of the transducer (MHz)
par.probeElementSize=0.1;                   % Size of the transducer elements (mm)
par.probeNumberElements=128;                % Number of elements (channels) of the transducer.
par.antiAliasCutoff=30;                     % Anti aliasing filter (MHz) accepted values 5,10,15,20,30.
par.LnaZinSel=25;                           % Amplifier impedance (integer 0 to 13)
par.HVset  = 20;                            % WARNING POWER: A HIGH VOLTAGE CAN DESTROY THE PROBE. simulation voltage. 

% compound definition
par.compoundAngles=[-6 -4 -2 0.25 2 4 6];   % WARNING POWER. Angles for the compound image (degrees).
par.compoundAverage = 3;                    % WARNING POWER. Number of averaging for each plane wave.
par.compoundAverageCoef=0.5;                % Multiplicative coefficient before averaging
par.compoundFrameRate =500;                 % WARNING POWER. Frame rate of compound images (Hz)
par.emissionLenght =2;                      % WARNING POWER. Number of stimulation cycles in plane wave emissions.

% imaging region and beamforming                   
par.imageOriginX=0;                         % First positon to image in the lateral dimension (mm)
par.imageOrigeiZ=3;                         % First position ro image in the depth dimension(mm)
par.imagePixelX=0.1;                        % Pixel dimension in the lateral dimension (mm)
par.imagePixelZ=0.075;                      % Pixel dimension in the depth dimension (mm)
par.imageNumberPixelsX=128;                 % Number of pixels in lateral (colons)
par.imageNumberPixelsZ=128;                 % Number of pixels in depth (rows)
par.imageNumericalApperture=1;              % Numerical apperture of the trasducer.
par.imageApodization=0.33;                   % Controls the beamforming apodization ( 0 to 1) 
par.soundSpeed=1.5;                         % Sound speed (mm/us)

% temporal resolution 
par.temporalResolutionNormal=5;             % In normal mode it fixes the temporal resolution (units of 0.1s)
par.numberVascularImages=70;                % Total number of images in a fUS acquisition

% vascular filtering
par.vascularFilterSVD = 0.1;                % Fraction of singular values to eliminate ( between 0 to 1)
par.vascularFilerHighPass= 15;              % High pass filter cutoff (Hz).

% trigger
par.serialTriggerOut=[20 35];               % Number of image to send a serial port trigger out (list of values)
par.electronicTiggerOut=0;                  % Sets the TTL trigger out (0 off 1 on)

% motor 
par.motorRandom = 0;                        % If 1 it activates the random mode if 0 it activates a linear scan
par.motorPositions=[0.25 0.75 0.5];         % If mode is random select positions.

% other specific parameters of the electronics
par.DebugTiming = 0;                        % must be 0 or 1.  when 1 there is a warning each time the sequencer lost some time.
par.codeSampleMode=2;                       % must be 2 or 4. 2 sets the mode 'BS100BW' and 4 the mode 'BS200BW' the other modes are not legal.
par.InputFilter= [+0.00058 +0.00018 -0.00113 -0.00128 -0.00119 +0.00656 -0.00085 +0.00394 -0.02023 +0.01016 -0.00729 +0.04315 -0.03101 +0.00522 -0.07068 +0.06903 +0.01953 +0.09348 -0.16998 -0.23038 +0.56439];
par.TGC=[400 200];                          % coefficientts of the 41 tap input filter (see manual)  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Power Check:
% This code controls that the emission power is "reasonable" but the limits
% depends of the probe.  Check the limits in particular the MAXIMUALVOLTAGE
% after each changement of the probe.
% There is also a basic check of the firing rate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MAXIMALVOLTAGE=20;        % maximal voltage accepted by the probe
MAXIMALDUTYCYCLE=0.01;    % maximal emission duty cycle accepted by the probe
dutyCycle=length(par.compoundAngles)*par.compoundAverage*par.compoundFrameRate*par.emissionLenght/(par.probeFreq*1e6); 
if dutyCycle>MAXIMALDUTYCYCLE, error('emission duty cycle too high'); end
if par.HVset>MAXIMALVOLTAGE,   error('voltage too high'); end

%check the firing rate / imaging depth 
firingRate=length(par.compoundAngles)*par.compoundAverage*par.compoundFrameRate;
maximalDepth= par.soundSpeed/(firingRate*2)*1e6;
demandedMaximalDepth=par.imageOrigeiZ+par.imagePixelZ*par.imageNumberPixelsZ;
if maximalDepth<demandedMaximalDepth, error('firing rate too high for the imaging depth'); end
